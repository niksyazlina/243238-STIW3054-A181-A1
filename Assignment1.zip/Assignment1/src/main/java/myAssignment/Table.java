package myAssignment;

public class Table {
    private String Info1;
    private String Info2;
    //private int Num;


    public Table(String info1, String info2) {
        //Num = num;
        Info1 = info1;
        Info2 = info2;
    }

    public String getInfo1() {
        return Info1;
    }

    public void setInfo1(String info1) {
        Info1 = info1;
    }

   /* public int getNum() {
        return Num;
    }

    public void setNum(int num) {
        Num = num;
    }*/

    public String getInfo2() {
        return Info2;
    }

    public void setInfo(String info2) {
        Info2 = info2;
    }
}

    /*private String List;
    private String Info;

    public Table() {
    }

    public Table(String list, String info) {
        List = list;
        Info = info;
    }

    public String getList() {
        return List;
    }

    public void setList(String list) {
        List = list;
    }

    public String getInfo() {
        return Info;
    }

    public void setInfo(String info) {
        Info = info;
    }
} */