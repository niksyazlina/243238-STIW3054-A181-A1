package myAssignment;


import java.util.List;
import java.util.ArrayList;
public class Common {

    //public static final List<Table> trivia = new ArrayList();
    public static final int sleep = 3000;
    public static String url = "https://ms.wikipedia.org/wiki/Malaysia";
}
